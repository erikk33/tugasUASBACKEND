# Simple Profile Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/ImDezCode/pen/wvarVWw](https://codepen.io/ImDezCode/pen/wvarVWw).

